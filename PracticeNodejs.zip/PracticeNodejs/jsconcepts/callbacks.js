const values = [1,2,3,4,5];
const callbackFunc = (values,funcName) => {
for(let i=0;i<values.length;i++){
    funcName(values[i])
}
}

const callbackSquare = (squareVals) => {
    console.log('square: ',squareVals*squareVals);
}
const callbackCube = (cubVals)=>{
    console.log('cube:   ',cubVals*cubVals*cubVals);
}

callbackFunc(values,callbackSquare);
callbackFunc(values,callbackCube);
 

/** */