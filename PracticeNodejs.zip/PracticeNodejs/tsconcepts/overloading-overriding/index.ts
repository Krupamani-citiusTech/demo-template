/**overloading - same number of parameters with different types */

// function add(a:string,b:string):string;

// //function with number type parameters

// function add(a:number,b:number):number;

// function add(a:any,b:any){
//     return a+b
// }

// //result
// console.log("addition:",add("Hello","Node"));
// console.log("addition:",add(3,4));

// method overriding

class Person {
    protected name:string;
    constructor(name:string){
        this.name = name;
    }
    eat(){
        console.log(`${this.name} eats when hungry!`)
    }
}

class Student extends Person{
    private age:number;
    constructor(name:string,age:number){
        super(name)
    }
    eat(){
        console.log(`${this.name} from person class`)
    }
}
const student = new Student("Hello",1);
student.eat();