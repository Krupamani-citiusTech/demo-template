/**overloading - same number of parameters with different types */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// function add(a:string,b:string):string;
// //function with number type parameters
// function add(a:number,b:number):number;
// function add(a:any,b:any){
//     return a+b
// }
// //result
// console.log("addition:",add("Hello","Node"));
// console.log("addition:",add(3,4));
// method overriding
var Person = /** @class */ (function () {
    function Person(name) {
        this.name = name;
    }
    Person.prototype.eat = function () {
        console.log("".concat(this.name, " eats when hungry!"));
    };
    return Person;
}());
var Student = /** @class */ (function (_super) {
    __extends(Student, _super);
    function Student(name, age) {
        return _super.call(this, name) || this;
    }
    Student.prototype.eat = function () {
        console.log("".concat(this.name, " from person class"));
    };
    return Student;
}(Person));
var student = new Student("Hello", 1);
student.eat();
