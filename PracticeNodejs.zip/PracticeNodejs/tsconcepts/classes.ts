class SuperClass {
    private name:string;
    public diseases:string;
    protected age:string;
    constructor(name:string,diseases:string,age:string){
     this.name = name;
     this.diseases = diseases;
     this.age = age;
    }
    getSuperMethod(){
     console.log(`fromSuperClass--->\n name(private) :${this.name}\n 
     diseases(public) : ${this.diseases}\n
     age(protected) :`,this.age);
    }
}

class SubClass1 extends SuperClass {
    public phoneNo:number
    constructor(name,diseases:string,age:string,phoneNo:number){
       super(name,diseases,age)
        this.phoneNo = phoneNo
    }
    getsubclass1Method(){
        console.log(`from subClass1--->\n phoneNo(private) :${this.phoneNo}\n 
        diseases(public) : ${this.diseases}\n
        age(protected) :`,this.age); 
    }
}

class SubChildClass extends SubClass1{
constructor(name:string,diseases:string,age:string,phoneNo:number){
    super(name,diseases,age,phoneNo)
}
getchildClassMethod(){
    console.log(`from childClass--->\n phoneNo(private) :${this.phoneNo}\n 
        diseases(public) : ${this.diseases}\n
        age(protected) :`,this.age); 
}
}

const superClass = new SubChildClass('krupa','fever','25',8765876633);
superClass.getSuperMethod();
superClass.getchildClassMethod();