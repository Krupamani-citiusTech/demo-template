// function display<T>( val:T):T{
//     return val
// }
// console.log(display<number>(123));
// console.log(display<string>("Hi"));
// function addVals<T>(item:T,arr:T[]):T[]{
//     return [item,...arr]
// }
// let strArrVals = addVals<string>("Hi",['arr1','arr2']);
// strArrVals.push('bye')
// console.log('strArrVals:',strArrVals);
function addVals(item, arr) {
    console.log('item:', item, 'arr:', arr);
}
addVals('Hi', [1, 2, 3, 4]);
