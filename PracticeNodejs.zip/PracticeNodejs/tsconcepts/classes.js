var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SuperClass = /** @class */ (function () {
    function SuperClass(name, diseases, age) {
        this.name = name;
        this.diseases = diseases;
        this.age = age;
    }
    SuperClass.prototype.getSuperMethod = function () {
        console.log("fromSuperClass--->\n name(private) :".concat(this.name, "\n \n     diseases(public) : ").concat(this.diseases, "\n\n     age(protected) :"), this.age);
    };
    return SuperClass;
}());
var SubClass1 = /** @class */ (function (_super) {
    __extends(SubClass1, _super);
    function SubClass1(name, diseases, age, phoneNo) {
        var _this = _super.call(this, name, diseases, age) || this;
        _this.phoneNo = phoneNo;
        return _this;
    }
    SubClass1.prototype.getsubclass1Method = function () {
        console.log("from subClass1--->\n phoneNo(private) :".concat(this.phoneNo, "\n \n        diseases(public) : ").concat(this.diseases, "\n\n        age(protected) :"), this.age);
    };
    return SubClass1;
}(SuperClass));
var SubChildClass = /** @class */ (function (_super) {
    __extends(SubChildClass, _super);
    function SubChildClass(name, diseases, age, phoneNo) {
        return _super.call(this, name, diseases, age, phoneNo) || this;
    }
    SubChildClass.prototype.getchildClassMethod = function () {
        console.log("from childClass--->\n phoneNo(private) :".concat(this.phoneNo, "\n \n        diseases(public) : ").concat(this.diseases, "\n\n        age(protected) :"), this.age);
    };
    return SubChildClass;
}(SubClass1));
var superClass = new SubChildClass('krupa', 'fever', '25', 8765876633);
superClass.getSuperMethod();
superClass.getchildClassMethod();
