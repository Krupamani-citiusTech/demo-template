const fs = require("fs");

/*write the file with buffer */
// const data = new Uint8Array(Buffer.from('Hello Node.js'));
// fs.writeFile('fs-example.txt',data,(err)=>{
// console.log('fs-exxample.txt is saved with given text')
// })

/* read a file using fs.readFile*/
// fs.readFile('fs-example.txt',"utf-8",(err,data)=>{
//     console.log('data from fs-example.txt file--->',data)
// })

/*append text*/
// fs.appendFile('fs-example.txt','this file is updated with this text',(err)=>{
//     if(err) throw err;
//     console.log('updated!')
// })

/*delete file*/
// fs.unlink('fs-example.txt',(err)=>{
//     if (err) return err
//     console.log('deleted!!!')
// })

/*-------rename--------*/
// fs.rename('fs-example.txt','fs-example1.txt',(err)=>{
//     console.log('file name is changed!!!')
// })


fs.readFile(__dirname + "/file.html","utf8",(err,data)=>{
    if (err) return err;
    console.log('data: ',data)
})