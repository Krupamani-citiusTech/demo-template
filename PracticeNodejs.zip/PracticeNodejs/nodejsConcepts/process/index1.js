const processArgv = require("./index")

processArgv.process_argv()