const process = require("process")
const fs = require("fs"); 
//-------example-1------------
// process.stdout.write("Hello World!" + "\n");
// process.stdin.on('data', data => {
//     console.log(`You typed ${data.toString()}`);
//     // process.exit();
//   });

//--------example-2-------------
// process.stdin.on('readable', () => {
//     let chunk;
//     // Use a loop to make sure we read all available data.
//     while ((chunk = process.stdin.read()) !== null) {
//      process.stdout.write(`data: ${chunk}`);
//     }
//   });

const process_argv = () =>{
let argument_vector = process.argv;
if(argument_vector.length>=2){
    console.log(argument_vector[2])
    fs.appendFile("input.txt",argument_vector[2]+'\n',(err)=>{
    if(err)
    console.log('error: ',err);
    })
} else {
    console.log('No input data')
}
}

module.exports = {process_argv}