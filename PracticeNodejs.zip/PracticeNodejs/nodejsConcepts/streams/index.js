const fs=require('fs');
var data = ''
//readstream

// const readStream = fs.createReadStream("input.txt");

// readStream.setEncoding('utf-8');
// readStream.on('data',chunk=>{
//     data = chunk
// })
// readStream.on('end',()=>{
//     console.log('data: ',data);
// })

//writestream

// const writeStream = fs.createWriteStream('input.txt');
// writeStream.write('This is the input file data','utf-8');
// writeStream.end();

// writeStream.on('data',(data)=>{
//     console.log('writestream:',data)
// })

//pipe

// const readStream = fs.createReadStream("input.txt");
// const writeStream = fs.createWriteStream('ouput.txt');

// readStream.pipe(writeStream)


//chaining streams

//-------zlib.createGunzip()/zlib.createGzip()-------------

const zlib = require('zlib');
fs.createReadStream('input.txt').pipe(zlib.createGunzip()).pipe(fs.createWriteStream('output1.txt'))