const http = require("http");
const url = require('url');
/*create server object*/
// const requestListner = (req,res) => {
// res.writeHead('200',{'Content-Type' : 'text/html'})
// res.write('Hi,Server connceted!!!')
//  const q = url.parse(req.url,true).query;
// //  const {year,month} = q;
//  console.log('queryString:',q)
// }

// const server = http.createServer(requestListner);
// server.listen('9090','localhost',()=>{console.log('Server running on PORT: 9090')})

const express = require('express');
const app = express();
app.get('/hello',(req,res,next)=>{
    res.writeHead(200, {'Content-Type': 'text/plain'});
    // let q = url.parse(req.url,true).query;
    console.log('query:',req.url);
    res.end('hello citius-tech');
})

app.listen(3000)
console.log('server is running on port:3000')