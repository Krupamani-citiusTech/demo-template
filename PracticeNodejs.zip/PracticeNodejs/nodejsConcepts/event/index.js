
const eventEmitter = require("events").EventEmitter;
const emitter = new eventEmitter();

const handlerFunc = () => {
    console.log('handlerFunc');
}

// emitter.on('eventName',handlerFunc);

// emitter.emit('eventName')

// emitter.removeListener('eventName',()=>{
// console.log('removed Listner')
// })
// emitter.on('eventName',handlerFunc);

emitter.addListener('foo',handlerFunc);

emitter.emit('foo')

emitter.removeListener('foo',handlerFunc);
// emitter.on('foo',handlerFunc)
emitter.emit('foo')



