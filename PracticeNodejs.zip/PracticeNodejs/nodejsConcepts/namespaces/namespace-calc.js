"use strict";
exports.__esModule = true;
exports.Calc = void 0;
var Calc;
(function (Calc) {
    var Sub;
    (function (Sub) {
        function subtraction(num1, num2) {
            return num1 - num2;
        }
        Sub.subtraction = subtraction;
    })(Sub = Calc.Sub || (Calc.Sub = {}));
    var Mul;
    (function (Mul) {
        function multiply(num1, numb2) {
            return num1 * numb2;
        }
        Mul.multiply = multiply;
    })(Mul = Calc.Mul || (Calc.Mul = {}));
})(Calc = exports.Calc || (exports.Calc = {}));
