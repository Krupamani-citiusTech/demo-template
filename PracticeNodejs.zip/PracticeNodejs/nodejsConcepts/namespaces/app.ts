import {Sum} from './namespace-sum';
import {Calc} from './namespace-calc'

console.log('sum:',Sum.addition(1,2));
console.log('calc-sub:',Calc.Sub.subtraction(2,1));
console.log('calc-mul',Calc.Mul.multiply(2,1));