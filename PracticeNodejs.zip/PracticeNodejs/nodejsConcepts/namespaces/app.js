"use strict";
exports.__esModule = true;
var namespace_sum_1 = require("./namespace-sum");
var namespace_calc_1 = require("./namespace-calc");
console.log('sum:', namespace_sum_1.Sum.addition(1, 2));
console.log('calc-sub:', namespace_calc_1.Calc.Sub.subtraction(2, 1));
console.log('calc-mul', namespace_calc_1.Calc.Mul.multiply(2, 1));
