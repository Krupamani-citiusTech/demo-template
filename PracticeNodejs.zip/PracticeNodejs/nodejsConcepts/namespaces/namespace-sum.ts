export namespace Sum{
export function addition(n1,n2){
    return n1+n2;
}
}