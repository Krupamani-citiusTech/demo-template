"use strict";
exports.__esModule = true;
exports.Sum = void 0;
var Sum;
(function (Sum) {
    function addition(n1, n2) {
        return n1 + n2;
    }
    Sum.addition = addition;
})(Sum = exports.Sum || (exports.Sum = {}));
