export namespace Calc{
export namespace Sub{
    export function subtraction(num1:number,num2:number){
        return num1-num2
    }
}
export namespace Mul{
    export function multiply(num1:number,numb2:number){
        return num1 * numb2
    }
}
}