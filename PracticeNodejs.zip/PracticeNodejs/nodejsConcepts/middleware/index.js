const connect = require('connect');
const http = require('http');

const app = connect();

app.use((req,res,next)=>{
    next()
})
const todo = (data)=>{
    return((req,res,next)=>{
        return res.end(data)
    })
}
app.use('/todo',todo('This is todo'))
const server = http.createServer(app);
server.listen('9090','localhost',()=>{console.log('server running on port 9090:')})