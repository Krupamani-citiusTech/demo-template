const http = require('http');
const url = require('url');

// const requestListner = (req,res)=>{
//     if(req.url == '/hello'){
//         console.log('req.url',req.url)
//         res.writeHead(200, {'Content-Type': 'text/plain'});
//         res.end(req.url)
//     }

// };

//-------------------static-url-----------------------
// var adr = 'http://localhost:8080/default.htm?year=2017&month=february';
// let q = url.parse(adr,true);
//     console.log('query:',q)
//     console.log('host:',q.host)
//     console.log('port:',q.port)
//     console.log('year:',q.query.year)
//     console.log('month:',q.query.month)
//----------------query string--------------------
 queryString = require('querystring');
// const obj1 = queryString.parse('firstname=krupa&lastname=makana')
// console.log('firstname:',obj1.firstname,'lastname:',obj1.lastname);

const obj1 = queryString.stringify({firstname:'krupa',lastname:'makana'})
console.log('obj1',obj1)
// const server = http.createServer(requestListner);
// server.listen('9092','localhost',()=>{console.log('server running on port 9092:')})