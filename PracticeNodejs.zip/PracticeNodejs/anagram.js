function findAnagram(word, myarr) {

    let wordLen = word.length;

    let wordSortJoin = word.split("").sort().join("");

    for (let i = 0; i < myarr.length; i++) {

        let sinWordLen = myarr[i].length;

        if (wordLen === sinWordLen) {

            if (wordSortJoin.includes(myarr[i].split("").sort().join(""))) {

                console.log(`${myarr[i]} is anaragram to ${word}`)

            }



        }




    }

}





findAnagram('racer', ['crazer', 'carera', 'racara', 'racera'])