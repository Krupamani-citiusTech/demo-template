import React from 'react';
import axios from 'axios'
class HtmlPug extends React.Component{
    constructor(props){
        super(props);
        this.state = {
         htmlPug : ''
        }
    }
    componentDidMount(){
    axios.get('http://localhost:9000/htmlPug').then((res)=>{
        this.setState({htmlPug:res.data})
    })
    }
    render(){
        return(
            <div dangerouslySetInnerHTML={{__html: this.state.htmlPug}}></div>
        )
    }
}
export default HtmlPug;