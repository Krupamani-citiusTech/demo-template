import React from 'react';
import axios from 'axios';
class SendMsg extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            msg : ''
        }
    }
    handleChange = (e) => {
    this.setState({msg:e.target.value})
    }
    handleClick = (e) => {
        e.preventDefault();
        console.log('message from client:: ',this.state.msg);
        axios.post('http://localhost:9000/sendMsg',{msg:this.state.msg});
     }
    render(){
        return(
            <div>
                message :
                <input type="text" value = {this.state.msg} onChange={this.handleChange}/>
                <button onClick={this.handleClick}>Send</button>
            </div>
        )
    }
}
export default SendMsg;