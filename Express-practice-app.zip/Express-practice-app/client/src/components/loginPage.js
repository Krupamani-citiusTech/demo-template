import React from "react";
import axios from 'axios';
class LoginPage extends React.Component{
    constructor(props){
        super(props);
        this.state = {
        name : '',
        password : '',
        foundName : '',
        findUser : []
        }
    }
    inputHandler = (e) =>{
        e.preventDefault();
        const { id, value } = e.target;
        this.setState(prevState => ({
            ...prevState,
            [id]: value
        }));
    }
    handleSubmit = (e) =>{
        e.preventDefault()
        console.log('username: ',this.state.name,'password: ',this.state.password)
        const {name,password} = this.state;
    
       axios.post("http://localhost:9000/users",{
           name : name,
           password : password
       }).then(res=>{
           console.log('res from login: ', res)
       })
    }
    searchUser = (e) => {
        e.preventDefault();
        console.log('foundUser:: ',this.state.foundName)
        // axios.get('http://localhost:9000/users').then(res=>{
        //     console.log('res',res.data);
        //     const findUser = res.data.find(val=>val.name===this.state.foundName);
        //     console.log('findUser',findUser);
        //     this.setState({findUser:findUser})
        // })
        axios.get(`http://localhost:9000/users/${this.state.foundName}`).then(res=>{
            console.log('res from client:',res.data)
            this.setState({findUser:res.data})
        })
            
    }
    render(){
        return(
            <div>
                <center>
            <form onSubmit = {this.handleSubmit}>
                Username : <input type="text" value={this.state.name} id='name' onChange={this.inputHandler}/><br/>
                Password : <input type="password" value={this.state.password} id='password' onChange={this.inputHandler}/><br/>
                <button>Login</button>
            </form>
            <form onSubmit = {this.searchUser}>
            Search User : <input type="text" value={this.state.foundName} id='foundName' onChange={this.inputHandler}/>&nbsp;
            <button>Search</button>
            </form>
            {console.log('render',this.state.findUser)}
          {(this.state.findUser.length !==0 )?
           `username:  ${this.state.findUser.name} 
             password:  ${this.state.findUser.password}`
           :
           'Search For user'
          }
          
            </center>
            </div>
        )
    }
}
export default LoginPage;