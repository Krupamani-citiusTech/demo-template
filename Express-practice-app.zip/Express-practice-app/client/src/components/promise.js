import React from 'react';
import axios from 'axios'
class PromiseComp extends React.Component{
    
    componentDidMount(){
    //promise all
    // const url1 = axios.get('https://jsonplaceholder.typicode.com/todos/1');
    // const url2 = axios.get('https://jsonplaceholder.typicode.com/todos/2');
    // const url3 = axios.get('https://jsonplaceholder.typicode.com/todos/3');
    // Promise.any([url1,url2,url3]).then(res=>{
    //     console.log('response: ',res)
    // }).catch(err=>{
    //     console.log(err);
    // })

//Promise chaining
  axios.get('https://jsonplaceholder.typicode.com/todos/1')
  .then(async(response) => {
      return await response
  })
  .then(response => {
    console.log('response1',response)
    return axios.get('https://jsonplaceholder.typicode.com/todos/2')
  }).catch(err=>console.log(err))
  .then(response => {
    console.log('response2',response)
    return axios.get('https://jsonplaceholder.typicode.com/todos/3')
  }).then(response=>{
    console.log('response3',response)
  }).catch(error => console.log(error));
    }

    render(){
        return(
          <div></div>
        )
    }
}
export default PromiseComp;