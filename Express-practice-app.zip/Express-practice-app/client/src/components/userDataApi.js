import React from 'react';
import axios from 'axios'
class UserDataApi extends React.Component{
    constructor(props){
        super(props);
        this.state = {
         userData : ''
        }
    }
    componentDidMount(){
    axios.get('http://localhost:9000/user').then((res)=>{
        this.setState({userData:res.data})
    })
    }
    render(){
        return(
            <div>{this.state.userData}</div>
        )
    }
}
export default UserDataApi;