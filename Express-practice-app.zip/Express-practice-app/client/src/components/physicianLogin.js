import React from "react";
import axios from 'axios';
class PhysicianLogin extends React.Component{
    constructor(props){
        super(props);
        this.state = {
        physicianName : '',
        password : ''
        }
    }
    inputHandler = (e) =>{
        e.preventDefault();
        const { id, value } = e.target;
        this.setState(prevState => ({
            ...prevState,
            [id]: value
        }));
    }
    handleSubmit = (e) =>{
        e.preventDefault()
        console.log('username: ',this.state.physicianName,'password: ',this.state.password)
        const {physicianName,password} = this.state;
    
       axios.post("http://localhost:9000/physician",{
        physicianName : physicianName,
           password : password
       })
    }
    render(){
        return(
            <div>
                <center>
            <form onSubmit = {this.handleSubmit}>
                PhysicianName : <input type="text" value={this.state.physicianName} id='physicianName' onChange={this.inputHandler}/><br/>
                Password : <input type="password" value={this.state.password} id='password' onChange={this.inputHandler}/><br/>
                <button>Login</button>
            </form>
            </center>
            </div>
        )
    }
}
export default PhysicianLogin;