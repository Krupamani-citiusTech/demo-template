import React from "react";
import axios from 'axios';
import { Base_url } from "../url";
class Register extends React.Component{
    constructor(props){
        super(props);
        this.state = {
        name : '',
        password : '',
        }
    }
    inputHandler = (e) =>{
        e.preventDefault();
        const { id, value } = e.target;
        this.setState(prevState => ({
            ...prevState,
            [id]: value
        }));
    }
    handleSubmit = (e) =>{
        e.preventDefault()
        console.log('url: ',axios)
        console.log('username: ',this.state.name,'password: ',this.state.password)
        const {name,password} = this.state;
    
       axios.post(`${Base_url}/register`,{
           name : name,
           password : password
       }).then(res=>{
           console.log('res from login: ', res)
       })
    }
    render(){
        return(
            <div>
                <center>
            <form onSubmit = {this.handleSubmit}>
                Username : <input type="text" value={this.state.name} id='name' onChange={this.inputHandler}/><br/>
                Password : <input type="password" value={this.state.password} id='password' onChange={this.inputHandler}/><br/>
                <button>Register</button>
           </form>
          
            </center>
            </div>
        )
    }
}
export default Register;