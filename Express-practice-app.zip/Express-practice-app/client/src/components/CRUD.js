import axios from "axios";
import React from "react";
import {connect} from 'react-redux';
import * as actionCreators from '../state-management/action-creators/userActions';
class ReactCrud extends React.Component{
constructor(props){
super(props);
// this.name = React.createRef()
this.state = {
    allUsers : [],
    open_popup:false,
    name:'',
    _id:''
}
}
componentDidMount(){
    // this.props.getUsersData();
    // console.log('from store',this.props.allUsersData)
    // this.setState({
    //     allUsers : this.props.allUsersData
    // })
    this.findUser()
}
findUser(){
    this.props.getUsersData();
    console.log('from store',this.props.allUsersData)
    this.setState({
        allUsers : this.props.allUsersData
    })
}
deleteUser = (userVals) => {
this.props.deleteUserData(userVals);
 this.findUser()
}
editUser = (userVals) =>{
console.log('userVals:',userVals,userVals._id);
this.setState({
    allUsers : userVals,
    name : userVals.name
})
// const {name}

console.log('from store-update',this.props.allUsersData)
// this.name = userVals.name;
// axios.put('/demographics' + '/' + userData.id, userData)
// console.log('current edited val',this.userName.current.value)
}
inputHandler = (e)=>{
    e.preventDefault();
    this.setState({
        name: e.target.value
    })
    
}
nameHandler = (e) => {
e.preventDefault();
if(this.state.allUsers._id){
   this.state.allUsers.name = this.state.name;
  
    console.log('name hadler',this.state.allUsers)  
    this.editUser(this.state.allUsers)
    // axios.patch('http://localhost:9000/updateUser' + '/' + this.state.allUsers._id, this.state.allUsers).then(res=>{
    //     console.log('post call responce',res)
    // })
    this.props.updateUserData(this.state.allUsers);
}

}
render(){
    return(
        <div>React Crud component
            {  console.log('from store - render',this.props.allUsersData)}
  <table className="table">
  <thead>
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Edit&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
      {this.props.allUsersData.map((vals,inx)=>(
          <tr key={inx}>
          <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{vals.name}</td>
          <td><button onClick={() => this.editUser(vals)}>Edit</button></td>
          <td><button onClick={() => this.deleteUser(vals)}>Delete</button></td> 
          </tr>
  ))}
   
  </tbody>
</table>
<div>
    <form onSubmit={this.nameHandler}>
    <input type = "text" value={this.state.name}  onChange={this.inputHandler}/>
    <button>Submit</button>
    </form>
</div>
        </div>
    )
}
}
const mapStateToProps = (appReducer)=>{
    console.log('mapStateToProps:',appReducer.userData.users)
    return {
        allUsersData : appReducer.userData.users
    }

}
const mapDispatchToProps = (dispatch)=>{
    return {
   getUsersData :()=>dispatch(actionCreators.UserActions()),
   deleteUserData : (userVals)=>dispatch(actionCreators.DeleteUserAction(userVals)),
   updateUserData : (user) => dispatch(actionCreators.UpdateUserAction(user))
}
}
let hoc = connect(mapStateToProps,mapDispatchToProps)
export default hoc(ReactCrud);
// export default ReactCrud;