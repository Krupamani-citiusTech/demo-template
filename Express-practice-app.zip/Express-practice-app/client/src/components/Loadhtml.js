import React from 'react';
import axios from 'axios'
class HtmlApi extends React.Component{
    constructor(props){
        super(props);
        this.state = {
         htmlFile : ''
        }
    }
    componentDidMount(){
    axios.get('http://localhost:9000/htmlFile').then((res)=>{
        this.setState({htmlFile:res.data})
    })
    }
    render(){
        return(
            <div dangerouslySetInnerHTML={{__html: this.state.htmlFile}}></div>
        )
    }
}
export default HtmlApi;