import React from 'react';
import axios from 'axios'
class GetDataApi extends React.Component{
    constructor(props){
        super(props);
        this.state = {
         getData : ''
        }
    }
    componentDidMount(){
    axios.get('http://localhost:9000/').then((res)=>{
        this.setState({getData:res.data})
    })
    }
    render(){
        return(
            <div>{this.state.getData}</div>
        )
    }
}
export default GetDataApi;