const appState = {
    users : []
}
export default appState;