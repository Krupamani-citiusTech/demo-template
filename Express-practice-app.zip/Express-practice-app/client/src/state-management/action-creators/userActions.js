import { userService } from "../../service/userService"
import * as actionCreators from '../actions'
export const UserActions = () =>{
    return dispatch => {
        userService.getAllUsers().then((res) => {
        console.log('res',res.data)
        dispatch({type:actionCreators.GET_ALL_USERS,users:res.data})
        }).catch(err=>{
            return console.log(err)
        })
    }
}
export const DeleteUserAction = (userVals) => {
    console.log('userVals',userVals)
    return dispatch =>{
        userService.deleteUser(userVals).then(res=>{
            console.log('delete-user:',res.data)
            dispatch({type:actionCreators.DELETE_USER,users:res.data})
        })
    }
}
export function UpdateUserAction(user) {
    console.log('user from action creators', user)
    return (dispatch) => {
        userService.updateUser(user).then((res) => {
            console.log('dispatch-update useraction',res)
            dispatch({ type: actionCreators.UPDATE_USER, users:res.data })
        }, (error) => {
            return console.log('not working')
        })
    }

}
