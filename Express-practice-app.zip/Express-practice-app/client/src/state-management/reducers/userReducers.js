import * as actionCreators from '../actions';
import appState from '../app-state';

const userReducers = (state=appState,action)=>{
console.log('actions from reducer',action)
if(action.type === actionCreators.GET_ALL_USERS){
    return{
        users : action.users
    }
} else if(action.type === actionCreators.DELETE_USER){
    console.log('delete users..........')
    return{
       users : action.users,
        ...state,
    
    }
} else if(action.type === actionCreators.UPDATE_USER){
    console.log('action-update',action.users)
    return {
       
        users : action.users,
        ...state
    }
}
else {
    return state;
}
}
export default userReducers;