import logo from './logo.svg';
import './App.css';
import UserDataApi from './components/userDataApi';
import GetDataApi from './components/getDataApi';
import {Routes,Route, BrowserRouter} from 'react-router-dom';
import HtmlApi from './components/Loadhtml';
import HtmlPug from './components/htmlPug';
import LoginPage from './components/loginPage';
import SendMsg from './components/sendMsg';
import PhysicianLogin from './components/physicianLogin';
import PromiseComp from './components/promise';
import Register from './components/register';
import ReactCrud from './components/CRUD';

function App() {
  return (
     <div>
       <BrowserRouter>
       <Routes>
       <Route path='/user' element={<UserDataApi/>}/>
       <Route path='/promise' element={<PromiseComp/>}/>
       <Route path='/html' element={<HtmlApi/>}/>
       <Route path='/pug' element={<HtmlPug/>}/>
       <Route path='/register' element={<Register/>}/>
       <Route path='/crud' element={<ReactCrud/>}/>
       <Route path='/login' element={<LoginPage/>}/>
       <Route path = '/physician' element={<PhysicianLogin/>}/>
       <Route path='/message' element={<SendMsg/>}/>
       <Route path='/' element={<GetDataApi/>}/>
       </Routes>
       </BrowserRouter>
    </div>
  );
}

export default App;
