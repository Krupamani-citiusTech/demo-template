import axios from "axios";
import { Base_url } from "../url";

class UserService {
getAllUsers(){
let url = Base_url+'/getUsers';
return axios.get(url);
}
deleteUser(userVals){
    let url = Base_url+'/deleteUser/'+ userVals._id;
    return axios.delete(url)
} 
updateUser(userData){
    console.log('from service-updateUser',userData)
    let url = Base_url+'/updateUser/'+ userData._id;
    let config = {
        headers : {
            'Content-Type':'application/json'
        }
    }
    return axios.patch(url, userData,config) 
}
}

const userService = new UserService();
export {userService}