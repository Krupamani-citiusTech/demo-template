const express = require('express');
const GetRouter = express.Router();
const path = require('path');
const PhysicianModel = require('../model/physicianmodel');
const UserModel = require('../model/usermodel');
const createUsers = require("../controller/user.controller")
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const MY_KEY = "My Super Secret Key";
let token = null;
let _name = ''
// const loginData = require('../model/usermodel')
GetRouter.post('/sendMsg', (req, res, next) => {
    // res.send('Login Form')
    console.log('coming to sendMsg', req.body.msg)

});

GetRouter.get('/loginData', (req, res, next) => {
    res.send('Login Form')
});

GetRouter.get('/getUsers',async (req,res,next)=>{
    const findUsers = await UserModel.find();
    return res.send(findUsers);
})
GetRouter.delete('/deleteUser/:id',async (req,res,next)=>{
    try {
        const deleteResult = await UserModel.findByIdAndRemove(req.params.id);
        console.log('delete-ser',deleteResult)
        return res.send(deleteResult);
      } catch (err) {
        console.log(err);
        return res.send(err).status(500);
      }
})
GetRouter.patch('/updateUser/:id',async (req, res) => {
    console.log('update',req.params,req.body);
    const { id } = req.params;
    try {
      const updateResult = await UserModel.findByIdAndUpdate(id, req.body);
      return res.send(updateResult);
    } catch (err) {
      console.log(err);
      return res.send(err).status(500);
    }
  });

GetRouter.post('/register',async (req,res) => {
    console.log('coming to register')
const { name, password } = req.body;
// const hashedPassword = bcrypt.hashSync(password)
// const body = {name, password : hashedPassword}
 const body = {name, password}
// console.log('coming to register',body);
const newUser = new UserModel(body)
const createdUser = await newUser.save();
// console.log('coming to users--->',createdUser)
return res.json(createdUser).status(201);
})

GetRouter.post('/users', async(req, res, next) => {
    // console.log('users-req.body', req.body)
    
    const { name, password } = req.body;
   
    const findUser = await UserModel.findOne(req.body);
    console.log('findUser:',findUser)
    if (findUser) {
        //write code for authenticating the user from database
        const token = jwt.sign({ name }, MY_KEY);
        _name = name;
        // console.log('token:',token)
        return res.send({ token })

        //   createUsers.foundUsers(req.body,res)
    } else {
        return res.send({message:"Invalid user"})
    }
});

const ensureToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    // console.log('token',authHeader);
    if (!authHeader) {
        return res.send({ error: 'auth header not available' })
     }
    token = authHeader?.split(" ")[1];
    // console.log('req header: ', token);
    next()

}
GetRouter.get('/protected', ensureToken, (req, res) => {
    // console.log('coming to protected')
    if (token !== '') {
        jwt.verify(token, MY_KEY, (err, decode) => {
            if (err) {
                return res.send(err)
            } else {
                console.log('Decode: ', decode)
                const { name } = decode;
                if (name === _name) {
                    return res.send({ message: "SUCCESS" })
                } else {
                    return res.send({ message: "Token error" })
                }
            }
        })
    } else {
        return res.send({ error: "Token not found" })
    }
})

GetRouter.get('/users/:name', async (req, res, next) => {
    const allUsers = await UserModel.find();
    // console.log('find user--->', allUsers.find(val => val.name === req.params.name))
    return res.json(allUsers.find(val => val.name === req.params.name))

    // console.log('params',req.params.username)
    //  const foundUserData =Object.entries(allUsers).find(allUsers.name === req.params.username)
    //     const foundUserData = Object.entries(allUsers).map((val,index)=>{
    //    console.log('find',val[index].name)
    //     })

    // const foundUser = await UserModel.findById(req.params.username);
    // return res.send(foundUser);
})


GetRouter.post('/physician', async (req, res, next) => {
    // for getting the data from database
    // const allUsers = await UserModel.find()
    // return res.json(allUsers)
    // for saving the data into the database
    const newUser = new PhysicianModel(req.body)
    const createdUser = await newUser.save();
    // console.log('coming to physician--->', createdUser)

    return res.json(createdUser).status(201);
})

GetRouter.get('/welcome', (req, res, next) => {
    res.send('Welcome')
})


GetRouter.get('/user1', (req, res, next) => {
    res.send('Getting Data from api call(/user)')
})

GetRouter.get('/htmlFile', (req, res, next) => {
    res.sendFile(path.join(__dirname + '/index.html'))
})

GetRouter.get('/htmlPug', (req, res) => {
    res.render('index', { title: 'Hey', message: 'Hello there!' })
})

GetRouter.get('/things/:id([0-9]{5})', (req, res) => {
    res.send('id: ' + req.params.id);
});


GetRouter.get('/', (req, res, next) => {
    res.send('Getting Data from api call(/)')
})

module.exports = GetRouter;