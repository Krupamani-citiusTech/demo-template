const express = require('express');
// const { findUsers } = require('../controller/user.controller');

const userRouter = express.Router();

userRouter.get('/users',(req, res,next) => {
    res.send('users Data')
});

module.exports = {userRouter}