const UserModel = require('../model/usermodel')
const findUsers = async (req,res)=>{
    try{
 const allUsers = await userModel.find()
 return res.json(allUsers)
    }catch(err){
        console.log(err);
        return res.send(err).status(500)
    }
}
const foundUsers =  async (req,res) => {
    
    //for getting the data from database
    // const allUsers = await UserModel.find()
    // return res.json(allUsers)
    //for saving the data into the database
    const newUser = new UserModel(req)
    const createdUser = await newUser.save();
    console.log('coming to users--->',createdUser)

    return res.json(createdUser).status(201);
}
module.exports = {findUsers,foundUsers}