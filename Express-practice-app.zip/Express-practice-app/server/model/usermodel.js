const { Schema, model } = require("mongoose");


const userSchema = new Schema({
     name : 'string',
     password : 'string',
})
const UserModel = model("usersData",userSchema);
module.exports = UserModel;