const {Schema,model} = require('mongoose');

const physicianSchema = new Schema({
    physicianName : 'string',
    password : 'string'
})

const PhysicianModel = model("PhysicianData",physicianSchema);

module.exports = PhysicianModel

