const  express = require('express');
const getDataRouter = require('./Router/getDataRouter');
const morgan = require('morgan');
const cors = require('cors');
const app = express();
require('./db')
const userRouter = require('./Router/userRouter')
//setting pug 
app.set('view engine', 'pug')
app.use(morgan('dev'))
app.use(cors())
app.use(express.json())
// app.use('/',userRouter)
app.use('/',getDataRouter);

app.listen(9000);
console.log('Server running on PORT:: 9000');